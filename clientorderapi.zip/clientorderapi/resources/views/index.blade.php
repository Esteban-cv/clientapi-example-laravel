@extends('templates.base')
@section('title', 'Inicio')
@section('header', 'Inicio')
@section('content')
    <div class="row">
        <div class="col-lg-12 mb-4">
            <p align="justify">
                ORDER WEB es un aplicativo para la administración de órdenes de trabajo, En él para gestionar los siguientes módulos:
            </p>
            <p>
                <ul>
                    <li>Tipo de actividad</li>
                    <li>Causales</li>
                    <li>Observaciones</li>
                    <li>Técnico</li>
                    <li>Actividades</li>
                    <li>Ordenes</li>
                </ul>
            </p>
        </div>
    </div>   
@endsection