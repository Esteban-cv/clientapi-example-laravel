function show_alert() {
    alert("ERROR");
}